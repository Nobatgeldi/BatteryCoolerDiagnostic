﻿// Decompiled with JetBrains decompiler
// Type: Peak.Can.Light.Hardware
// Assembly: CAN Tool, Version=1.0.0.16507, Culture=neutral, PublicKeyToken=null
// MVID: F3CD31CB-7674-4A71-ACFD-3BD33500CAD4
// Assembly location: C:\Program Files (x86)\CAN Tool\CAN Tool.exe

namespace Peak.Can.Light
{
  public enum Hardware
  {
    HW_ISA = 1,
    HW_DONGLE_SJA = 5,
    HW_DONGLE_SJA_EPP = 6,
    HW_DONGLE_PRO = 7,
    HW_DONGLE_PRO_EPP = 8,
    HW_ISA_SJA = 9,
    HW_PCI = 10, // 0x0000000A
  }
}
