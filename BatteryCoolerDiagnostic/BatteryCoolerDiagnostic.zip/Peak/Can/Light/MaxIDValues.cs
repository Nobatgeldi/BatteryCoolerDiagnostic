﻿// Decompiled with JetBrains decompiler
// Type: Peak.Can.Light.MaxIDValues
// Assembly: CAN Tool, Version=1.0.0.16507, Culture=neutral, PublicKeyToken=null
// MVID: F3CD31CB-7674-4A71-ACFD-3BD33500CAD4
// Assembly location: C:\Program Files (x86)\CAN Tool\CAN Tool.exe

namespace Peak.Can.Light
{
  public enum MaxIDValues
  {
    MAX_STANDARD_ID = 2047, // 0x000007FF
    MAX_EXTENDED_ID = 536870911, // 0x1FFFFFFF
  }
}
