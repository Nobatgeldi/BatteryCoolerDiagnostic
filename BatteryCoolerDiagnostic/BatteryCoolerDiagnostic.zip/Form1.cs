﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Resources;
using System.Threading;
using System.Windows.Forms;
using Peak.Can.Light;
using SiE.SiEAPI_Interface;
using SiE.SiEAPI_Interface.SiEAPI_InterfaceTypes;
using Timer = System.Windows.Forms.Timer;
using System.Text;
using Newtonsoft.Json;

namespace BatteryCoolerDiagnostic
{
    public partial class Form1 : Form
    {
        public string exe_root_path = Application.StartupPath + "\\";
        public string config_path = Application.StartupPath + "\\config\\";
        public string message_logs_path = Application.StartupPath + "\\message_logs\\";
        public string message_logs_excel_path = Application.StartupPath + "\\message_logs\\excel\\";
        public string message_logs_log_path = Application.StartupPath + "\\message_logs\\log\\";
        private string sw_name = "Battery Cooler Diagnostic Tool - COVISART";
        private Timer tmrRead_CanFox;
        private CCanChannel cCanChannelUsbCh1;
        private eErrorCodesCanChannel eRet;
        private HardwareType ActiveHardware;
        private ArrayList LastMsgsList;
        private AutoResetEvent RcvEvent;
        private uint _counterNodeIdPing = 1;
        private readonly uint battery_cooler_receive_id = 1500;
        private ReadDelegateHandler _readDelegate;
        private Thread _readThread;
        private CDeviceList deviceList;
        private CDevice device;
        public Form1()
        {
            InitializeComponent();
            ActiveHardware = ~HardwareType.USB_1CH;
            LastMsgsList = new ArrayList();

            cCanChannelUsbCh1 = new CCanChannel();
            deviceList = new CDeviceList();
            var deviceListState = cCanChannelUsbCh1.CanGetDeviceList(deviceList);
            if (deviceListState != eErrorCodesCanChannel.CAN_SUCCESS || deviceList.Count <= 0) return;
            device = deviceList.get_GetDevice(0);
            //MessageBox.Show("Bağlı " + deviceList.Count + " adet cihaz bulundu. Cihaz: " + device.Name);
            Text = Text + @" - Bağlı Cihaz: " + device.Name;
            

        }
        private void button1_Click(object sender, EventArgs e)
        {

            eRet = cCanChannelUsbCh1.CanOpen(eNetNumbers.CAN_FOX_CH1, eEcho.ECHO_OFF, 100U, 100U, "CAN_Tool");

            connectionProgressBar?.PerformStep();

            if (eRet != eErrorCodesCanChannel.CAN_SUCCESS)
            {
                int num = (int)cCanChannelUsbCh1.CanClose();
                txtInfo.Clear();
                txtInfo.AppendText("Channel 1 Açık değil");
                txtInfo.AppendText(Environment.NewLine);
                txtInfo.AppendText("Bağlantı kurulmadı");
                txtInfo.AppendText(Environment.NewLine);
                connectionStatus.Text = "Disconnected";
            }
            if (eRet == eErrorCodesCanChannel.CAN_SUCCESS)
            {
                txtInfo.AppendText("Channel 1 açıldı");
                txtInfo.AppendText(Environment.NewLine);
                connectionProgressBar?.PerformStep();
            }

            eRet = cCanChannelUsbCh1.CanSetBaudrate(eBaudrates.KBITS250);
            connectionProgressBar?.PerformStep();
            if (eRet != eErrorCodesCanChannel.CAN_SUCCESS)
            {
                int num = (int)cCanChannelUsbCh1.CanClose();
                txtInfo.AppendText("Baud hızı ayarlanmadı");
                txtInfo.AppendText(Environment.NewLine);
                txtInfo.AppendText("Bağlantı kurulmadı");
                txtInfo.AppendText(Environment.NewLine);
                connectionStatus.Text = "Disconnected";
            }
            if (eRet == eErrorCodesCanChannel.CAN_SUCCESS)
            {
                txtInfo.AppendText("Baud hızı seti");
                txtInfo.AppendText(Environment.NewLine);
            }

            eRet = cCanChannelUsbCh1.CanSetFilterMode(eFilterModes.FILTER_MODE_NOFILTER);
            connectionProgressBar?.PerformStep();
            if (eRet != eErrorCodesCanChannel.CAN_SUCCESS)
            {
                int num = (int)cCanChannelUsbCh1.CanClose();
                txtInfo.AppendText("Filtre ayarlanmadı");
                txtInfo.AppendText(Environment.NewLine);
                txtInfo.AppendText("Bağlantı kurulmadı");
                txtInfo.AppendText(Environment.NewLine);
                connectionStatus.Text = "Disconnected";
                if (connectionProgressBar != null) connectionProgressBar.Value = 0;
            }
            if (eRet == eErrorCodesCanChannel.CAN_SUCCESS)
            {
                txtInfo.AppendText("Filtre seti");
                txtInfo.AppendText(Environment.NewLine);
                txtInfo.Text = "Bağlantı başarıyla kuruldu. \r\n";
                TextBox txtInfo1 = txtInfo;
                txtInfo1.Text = txtInfo1.Text + "Active Hardware: CanFox\t";
                TextBox txtInfo2 = txtInfo;
                txtInfo2.Text = txtInfo2.Text + "\r\nBaudrate: 250 Kbit \t";
                TextBox txtInfo3 = txtInfo;
                txtInfo3.Text = txtInfo3.Text + "\r\nMesaj tipi: CanFox\t";
                txtInfo.AppendText(Environment.NewLine);
                if (connectionProgressBar != null) connectionProgressBar.Value = 100;
                connectionStatus.Text = "Connected";

                var num1 = (int)cCanChannelUsbCh1.CanResetCounter();
                var num2 = (int)cCanChannelUsbCh1.CanClearBuffer();

                //tmrRead_CanFox_Tick();
                _readDelegate = tmrRead_CanFox_Tick;
                _readThread = new Thread(CANReadThreadFunc);
                _readThread.Start();
            }

            //tmrRead_CanFox_Tick();
        }
        private void tmrRead_CanFox_Tick()
        {
            var counterData = new CCounterData();

            //The function fetches counter information like number of received messages.
            var counterExtended = (int)cCanChannelUsbCh1.CanGetCounterExtended(counterData);

            var ccmsgArray = new CCMSG[(int)counterData.RxFrameCtr + (int)counterData.ErxFrameCtr];
            
            for (var index = 0; index < counterData.RxFrameCtr + counterData.ErxFrameCtr; ++index)
            {
                ccmsgArray[index] = new CCMSG();
                var num = (int)cCanChannelUsbCh1.CanRead(ccmsgArray[index]);
                var myMsg = new TCLightMsg
                {
                    ID = ccmsgArray[index].Id, 
                    Len = ccmsgArray[index].Len
                };
                switch (ccmsgArray[index].Extended)
                {
                    case 0:
                        myMsg.MsgType = MsgTypes.MSGTYPE_STANDARD;
                        break;
                    case 1:
                        myMsg.MsgType = MsgTypes.MSGTYPE_EXTENDED;
                        break;
                }
                myMsg.Data[0] = ccmsgArray[index].get_Data(0);
                myMsg.Data[1] = ccmsgArray[index].get_Data(1);
                myMsg.Data[2] = ccmsgArray[index].get_Data(2);
                myMsg.Data[3] = ccmsgArray[index].get_Data(3);
                myMsg.Data[4] = ccmsgArray[index].get_Data(4);
                myMsg.Data[5] = ccmsgArray[index].get_Data(5);
                myMsg.Data[6] = ccmsgArray[index].get_Data(6);
                myMsg.Data[7] = ccmsgArray[index].get_Data(7);
                message_parser(myMsg);
            }
            var num1 = (int)cCanChannelUsbCh1.CanResetCounter();
            var num2 = (int)cCanChannelUsbCh1.CanClearBuffer();
        }
        private void message_parser(TCLightMsg MyMsg)
        {
            if ((int)MyMsg.ID == (int)battery_cooler_receive_id)
            {
                message_parser_battery_cooler(MyMsg);
            }

            /*else if (MyMsg.ID == 1920U)
                dataCome.AppendText(MyMsg.ID.ToString()); //this.message_parser_battery_cooler_can_open(MyMsg);*/
        }
        private void message_parser_battery_cooler(TCLightMsg MyMsg)
        {
            //Console.WriteLine("battery_cooler Job " + MyMsg.Data[0].ToString());
            switch (MyMsg.Data[0])
            {

                /*case 14:
                    //txt_device_type.Text = @"J_14_C1_refrig_high_pressure:" + ((int)MyMsg.Data[2] & 1);
                    txt_device_type.Text = string.Format("J_14_C1_refrig_high_pressure: {0:F1}", (object)((double)BitConverter.ToInt16(MyMsg.Data, 1) / 10.0));
                    break;*/
                case 11:
                    if ((MyMsg.Data[2] & 1) != 0)
                        Console.WriteLine(@"J_2_Sys_err_7_lifecycle_CANopen:" + true);
                    else
                    {
                        Console.WriteLine(@"J_2_Sys_err_7_lifecycle_CANopen:" + false);
                    }
                    Console.WriteLine(@"J_2_Sys_err_7_lifecycle_CANopen: " + MyMsg.Data[2]);

                    break;
            }
        }
        private void disconnect_canfox()
        {
            int num1 = (int)cCanChannelUsbCh1.CanResetCounter();
            int num2 = (int)cCanChannelUsbCh1.CanClearBuffer();
            eRet = cCanChannelUsbCh1.CanClose();
            if (eRet != eErrorCodesCanChannel.CAN_SUCCESS)
            {
                txtInfo.AppendText("Channel 1 açık değil");
                txtInfo.AppendText(Environment.NewLine);
                connectionProgressBar.Value = 0;
                connectionStatus.Text = "Disconnected";
            }
            else
            {
                if (eRet == eErrorCodesCanChannel.CAN_SUCCESS)
                {
                    txtInfo.AppendText("Channel 1 kapalı");
                    txtInfo.AppendText(Environment.NewLine);
                }
                //this.tmrRead_CanFox.Enabled = false;
                txtInfo.AppendText("bağlantı koptu");
                txtInfo.AppendText(Environment.NewLine);
            }
            connectionStatus.Text = "Disconnected";
            connectionProgressBar.Value = 0;
        }
        private void CANReadThreadFunc()
        {
            CStatusData status = new CStatusData();
            while (cCanChannelUsbCh1.CanStatus(status) == eErrorCodesCanChannel.CAN_SUCCESS)
            {
                try
                {
                    Invoke(_readDelegate);

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    break;
                }
            }
        }
        private struct MessageStatus
        {
            private TCLightMsg Msg;
            private int iIndex;

            public MessageStatus(TCLightMsg CanMsg, int Index)
            {
                Msg = CanMsg;
                iIndex = Index;
            }

            public TCLightMsg CANMessage => Msg;

            public int Position => iIndex;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RcvEvent = new AutoResetEvent(false);
            LoadJson();
        }

        private void btn_disconnect_Click(object sender, EventArgs e)
        {
            disconnect_canfox();
        }

        private delegate void ReadDelegateHandler();

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if(_readThread != null && _readThread.IsAlive) _readThread.Abort();
            try
            {
                var items = JsonConvert.DeserializeObject<List<Item>>(configDisplay.Text);
                File.WriteAllText(config_path + "parametr.json", configDisplay.Text);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
                MessageBox.Show("Ayarlarda hata var, kayit edilmeden kapatilacak.");
            }
        }
        public void LoadJson()
        {
            using (var r = new StreamReader(config_path + "parametr.json"))
            {
                var data = r.ReadToEnd();
                configDisplay.Text = data;
                var items = JsonConvert.DeserializeObject<List<Item>>(data);
            }
        }

        public class Item
        {
            public int MUX;
            public string Variable;
            public string Type;
            public string Description;
            public string Note;
        }
    }
}
